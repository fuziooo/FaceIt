package org.main;

import java.util.List;
import java.util.logging.Logger;

import javax.websocket.server.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/main")	
public class Main {
	
	private static final Logger log = Logger.getLogger(Main.class.getName());
	UserService userService = new UserService();
	
	@GET
	@Path("/allusers")
	@Produces(MediaType.APPLICATION_XML)
	public List<User> getUsers() {
		return userService.getAllUsers();
	}
	
//	@GET
//	@Path("/{usersbyid}")	
//	@Produces(MediaType.APPLICATION_XML)
//	public User getUserByFirstId(@PathParam("usersbyid") long id) {
//		return userService.getUserById(id);
//	}
	
	// adding user
	@POST
	@Path("/adduser")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public User addUser(User user) {
		log.info("Added user- " + user);
		return userService.addUser(user);	
	}
	
	// updating user
	@PUT
	@Path("/{userid}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public User updateUser(@PathParam("userid") long id, User user) {
		user.setId(id);
		log.info("Updated user- " + user);
		return userService.updateUser(user);
	}	
	
	// deleting user
	@DELETE
	@Path("/{userid}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public void deleteUser(@PathParam("userid") long id) {
		log.info("Deleted user with id- " + id);
		userService.deleteUser(id);		
	}
}
