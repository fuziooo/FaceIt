package org.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.database.DatabaseMock;

public class UserService {
	
	// usign databse mock
	private Map<Long, User> users = DatabaseMock.getUsers();

	// creating default user for testing
	public UserService() {
		users.put(1L, new User("Ariel", "Jankowski", "Ar", "2321", "email", "UK"));
		users.put(2L, new User("John", "Smith", "John", "111", "email", "UK"));
	}
	
	// method for displaying all users from database mock
	public List<User> getAllUsers(){
		return new ArrayList<User>(users.values());
	}
	
	public User getUserById(long id) {
		return users.get(id);
	}
	
	public User getUserByFirstName(String firstName) {
		return users.get(firstName);
	}
	
	// method for adding user to database mock
	public User addUser(User user) {
		user.setId(users.size() + 1);
		users.put(user.getId(), user);
		return user;
	}
	
	// method for updating user in database mock
	public User updateUser(User user) {
		if (user.getId() <= 0) {
			return null;
		}
		users.put(user.getId(), user);
		return user;
	}
	
	// method for deleting user from database mock
	public User deleteUser(long id) {
		return users.remove(id);
	}


}
