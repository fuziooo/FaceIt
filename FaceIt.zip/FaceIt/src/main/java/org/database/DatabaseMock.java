package org.database;

import java.util.HashMap;
import java.util.Map;

import org.main.User;

public class DatabaseMock {
	
	// not thread safe because there is no concurency 
	private static Map<Long, User> users = new HashMap<>();
	
	public static Map<Long, User> getUsers() {
		return users;
	}

}
