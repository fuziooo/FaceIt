package org.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import java.util.logging.Logger;

import org.database.DatabaseMock;
import org.junit.jupiter.api.Test;
import org.main.Main;
import org.main.User;

class AddUserTest {
	
	private static final Logger log = Logger.getLogger(Main.class.getName());
	private Map<Long, User> users = DatabaseMock.getUsers();
	
	@Test
	void test() {
		long j = 111;
		long i = 222;
		users.put(j, 	new User("Ariel", "Jankowski", "Ar", "2321", "email", "UK"));
		users.put(i, new User("John", "Smith", "John", "111", "email", "UK"));
		//fail("Not yet implemented");
		
		assertTrue(DatabaseMock.getUsers().containsKey(j), "User exists in database");
		assertTrue(DatabaseMock.getUsers().containsKey(i), "User exists in database");
		log.info("Users with id= " + i + " and id= " + j + " exist in database mock");
	}
}
