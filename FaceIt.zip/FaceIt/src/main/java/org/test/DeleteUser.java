package org.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;
import java.util.logging.Logger;

import org.database.DatabaseMock;
import org.junit.jupiter.api.Test;
import org.main.Main;
import org.main.User;
import org.main.UserService;

class DeleteUser {
	
	private static final Logger log = Logger.getLogger(Main.class.getName());
	private Map<Long, User> users = DatabaseMock.getUsers();
	UserService userService = new UserService();
	
	@Test
	void test() {
		
		long j = 111;
		long i = 222;
		userService.addUser(new User("Ariel", "Jankowski", "Ar", "2321", "email", "UK"));
		userService.addUser(new User("John", "Smith", "John", "111", "email", "UK"));
		
		userService.deleteUser(i);
		userService.deleteUser(j);
		
		assertTrue(!userService.getAllUsers().contains(users.containsKey(i)));
		assertTrue(!userService.getAllUsers().contains(users.containsKey(j)));
		log.info("Users with id= " + i + " and id= " + j + " have been deleted from database mock");
	}

}
