REST API 

Application created by Maven.

Application allows to add new users to mock database. It also allows to modify the users and delete them. 
It uses Apache Tomcat 7.0 server to create http requests and display required values.

Link to display all users in database
http://localhost:8080/FaceIt/webapi/main/allusers

Link to add users
http://localhost:8080/FaceIt/webapi/main/addUser

Link to delete user 
http://localhost:8080/FaceIt/webapi/main/AAA
where AAA is the ID of the user you want to delete or modify

TESTS

There are three simple tests checking correctnes of the main features of the application.

REQUIREMENTS 
Java 1.8
Tomcat 7.0 